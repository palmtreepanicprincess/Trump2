# White House Archive (Android, Jetpack Compose)
Open this folder in Android Studio (Koala or newer), let Gradle sync, connect the Z Fold 5 (USB debugging), press Run.

Fold behavior
- Folded (cover screen): single pane; list -> tap -> full-screen viewer, Back returns.
- Unfolded (inner screen): list on the left, viewer on the right.
- Half-open "book" posture: list left page / viewer right page, split at the hinge.
- Half-open "tabletop" posture: viewer top / list bottom.
- Folding/unfolding never restarts the app, so your place is kept.

Uploads: ADD -> Letters & Docs (PDF, images, text, Word) or Photos. Files are copied into private app storage.
Viewers: pinch / double-tap zoom for images, scrolling PDF pages, text; Word files open in another app.
