package com.whitehousearchive

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class ArchiveViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ArchiveStore(app)
    private val _items = MutableStateFlow<List<ArchiveItem>>(emptyList())
    val items: StateFlow<List<ArchiveItem>> = _items.asStateFlow()
    private val _selectedId = MutableStateFlow<String?>(null)
    val selectedId: StateFlow<String?> = _selectedId.asStateFlow()

    init { viewModelScope.launch(Dispatchers.IO) { _items.value = store.load() } }

    fun select(id: String?) { _selectedId.value = id }
    fun fileOf(item: ArchiveItem): File = store.fileFor(item)

    fun import(uris: List<Uri>, category: Category) {
        viewModelScope.launch(Dispatchers.IO) {
            val added = uris.mapNotNull { store.import(it, category) }
            if (added.isEmpty()) return@launch
            val all = added.reversed() + _items.value
            store.save(all)
            _items.value = all
            if (added.size == 1) _selectedId.value = added.first().id
        }
    }

    fun update(item: ArchiveItem, title: String, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val all = _items.value.map {
                if (it.id == item.id) it.copy(title = title.ifBlank { it.title }, notes = notes) else it
            }
            store.save(all); _items.value = all
        }
    }

    fun delete(item: ArchiveItem) {
        viewModelScope.launch(Dispatchers.IO) {
            store.delete(item)
            val all = _items.value.filterNot { it.id == item.id }
            store.save(all); _items.value = all
            _selectedId.value = null
        }
    }
}
