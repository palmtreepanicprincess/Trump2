package com.whitehousearchive

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0A1F44)
val NavyDeep = Color(0xFF06142D)
val NavyCard = Color(0xFF12305F)
val Gold = Color(0xFFC9A227)
val GoldLight = Color(0xFFE6C75A)
val Crimson = Color(0xFFB22234)
val Cream = Color(0xFFF7F1E1)

private val Scheme = darkColorScheme(
    primary = Gold, onPrimary = Navy,
    secondary = Crimson, onSecondary = Cream,
    background = NavyDeep, onBackground = Cream,
    surface = Navy, onSurface = Cream,
    surfaceVariant = NavyCard, onSurfaceVariant = Cream,
    outline = Gold
)

private val Serif = FontFamily.Serif
private val Type = Typography(
    headlineSmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = Serif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Serif, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Serif, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.5.sp)
)

@Composable
fun WhiteHouseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Type, content = content)
}
