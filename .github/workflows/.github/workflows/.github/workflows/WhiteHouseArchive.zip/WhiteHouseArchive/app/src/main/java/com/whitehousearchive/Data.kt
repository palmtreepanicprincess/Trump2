package com.whitehousearchive

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class Category { CORRESPONDENCE, PHOTO }
enum class Kind { IMAGE, PDF, TEXT, OTHER }

data class ArchiveItem(
    val id: String,
    val title: String,
    val notes: String,
    val category: Category,
    val fileName: String,
    val mime: String,
    val addedAt: Long
) {
    val kind: Kind
        get() = when {
            mime.startsWith("image/") -> Kind.IMAGE
            mime == "application/pdf" -> Kind.PDF
            mime.startsWith("text/") -> Kind.TEXT
            else -> Kind.OTHER
        }
}

/** Copies imported files into app-private storage and keeps a small JSON index. */
class ArchiveStore(private val context: Context) {
    private val dir = File(context.filesDir, "archive").apply { mkdirs() }
    private val index = File(context.filesDir, "index.json")

    fun fileFor(item: ArchiveItem) = File(dir, item.fileName)

    fun load(): List<ArchiveItem> = runCatching {
        val arr = JSONArray(index.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ArchiveItem(
                o.getString("id"), o.getString("title"), o.optString("notes"),
                Category.valueOf(o.getString("category")), o.getString("fileName"),
                o.getString("mime"), o.getLong("addedAt")
            )
        }
    }.getOrDefault(emptyList())

    fun save(list: List<ArchiveItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("notes", it.notes)
                put("category", it.category.name); put("fileName", it.fileName)
                put("mime", it.mime); put("addedAt", it.addedAt)
            })
        }
        index.writeText(arr.toString())
    }

    fun import(uri: Uri, category: Category): ArchiveItem? = runCatching {
        val cr = context.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        var name = "Untitled"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        val id = UUID.randomUUID().toString()
        val ext = name.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(8)
        val stored = if (ext.isEmpty()) id else "$id.$ext"
        cr.openInputStream(uri)!!.use { input ->
            File(dir, stored).outputStream().use { input.copyTo(it) }
        }
        ArchiveItem(id, name.substringBeforeLast('.'), "", category, stored, mime, System.currentTimeMillis())
    }.getOrNull()

    fun delete(item: ArchiveItem) { fileFor(item).delete() }
}
