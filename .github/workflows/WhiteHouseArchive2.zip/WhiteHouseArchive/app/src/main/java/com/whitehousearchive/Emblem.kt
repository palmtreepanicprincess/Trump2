package com.whitehousearchive

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private fun starPath(c: Offset, outer: Float, inner: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val rad = if (i % 2 == 0) outer else inner
        val a = -PI / 2 + i * PI / 5
        val x = c.x + rad * cos(a).toFloat()
        val y = c.y + rad * sin(a).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

/** An original, decorative gold medallion: double ring, 13 stars, and a large center star. */
@Composable
fun SealEmblem(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val c = center
        val r = this.size.minDimension / 2f
        drawCircle(Gold, r * 0.96f, c, style = Stroke(r * 0.08f))
        drawCircle(GoldLight, r * 0.84f, c, style = Stroke(r * 0.02f))
        drawCircle(NavyCard, r * 0.80f, c)
        drawCircle(Crimson, r * 0.50f, c, style = Stroke(r * 0.03f))
        for (i in 0 until 13) {
            val a = -PI / 2 + i * 2 * PI / 13
            val p = Offset(c.x + (r * 0.66f * cos(a)).toFloat(), c.y + (r * 0.66f * sin(a)).toFloat())
            drawPath(starPath(p, r * 0.085f, r * 0.035f), GoldLight)
        }
        drawPath(starPath(c, r * 0.42f, r * 0.17f), Gold)
    }
}
