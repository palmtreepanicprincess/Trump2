package com.whitehousearchive

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0A1F44)
val NavyDeep = Color(0xFF06142D)
val NavyCard = Color(0xFF12305F)
val Gold = Color(0xFFC9A227)
val GoldLight = Color(0xFFE6C75A)
val Crimson = Color(0xFFB22234)
val Cream = Color(0xFFF7F1E1)

private val Scheme = darkColorScheme(
    primary = Gold, onPrimary = Navy,
    secondary = Crimson, onSecondary = Cream,
    background = NavyDeep, onBackground = Cream,
    surface = Navy, onSurface = Cream,
    surfaceVariant = NavyCard, onSurfaceVariant = Cream,
    outline = Gold
)

// Gloock: a stately high-contrast serif for headings. Crimson Pro: a classic book serif for reading.
val Heading = FontFamily(Font(R.font.gloock_regular, FontWeight.Normal))
val Body = FontFamily(
    Font(R.font.crimsonpro_regular, FontWeight.Normal),
    Font(R.font.crimsonpro_bold, FontWeight.Bold),
    Font(R.font.crimsonpro_italic, FontWeight.Normal, FontStyle.Italic)
)

private val Type = Typography(
    headlineSmall = TextStyle(fontFamily = Heading, fontWeight = FontWeight.Normal, fontSize = 24.sp),
    titleLarge = TextStyle(fontFamily = Heading, fontWeight = FontWeight.Normal, fontSize = 19.sp),
    titleMedium = TextStyle(fontFamily = Heading, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Body, fontSize = 18.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontFamily = Body, fontSize = 16.sp, lineHeight = 22.sp),
    labelLarge = TextStyle(fontFamily = Heading, fontWeight = FontWeight.Normal, fontSize = 13.sp, letterSpacing = 1.5.sp)
)

@Composable
fun WhiteHouseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Type, content = content)
}
