package com.whitehousearchive

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ImageViewer(file: File, onTap: (() -> Unit)? = null) {
    var scale by remember(file) { mutableFloatStateOf(1f) }
    var offset by remember(file) { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 6f)
        offset = if (scale == 1f) Offset.Zero else offset + pan
    }
    Box(Modifier.fillMaxSize().clipToBounds()) {
        AsyncImage(
            model = file,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
                .transformable(state)
                .pointerInput(file) {
                    detectTapGestures(onTap = { onTap?.invoke() }, onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                    })
                }
        )
    }
}

private class PdfDoc(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            runCatching {
                renderer.openPage(index).use { page ->
                    val w = width.coerceAtLeast(1)
                    val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            }.getOrNull()
        }
    }

    fun close() { runCatching { renderer.close(); pfd.close() } }
}

@Composable
fun PdfViewer(file: File, onTap: (() -> Unit)? = null) {
    val doc = remember(file) { runCatching { PdfDoc(file) }.getOrNull() }
    DisposableEffect(doc) { onDispose { doc?.close() } }
    if (doc == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("This PDF couldn't be opened.", color = Cream) }
    } else {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val widthPx = with(LocalDensity.current) { (maxWidth - 24.dp).roundToPx() }
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(doc.pageCount) { i ->
                    val bmp by produceState<Bitmap?>(null, doc, i, widthPx) { value = doc.render(i, widthPx) }
                    val b = bmp
                    if (b != null) {
                        Image(
                            b.asImageBitmap(), "Page ${i + 1}",
                            Modifier.fillMaxWidth().then(if (onTap != null) Modifier.clickable { onTap() } else Modifier),
                            contentScale = ContentScale.FillWidth
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.77f).background(Color.White), Alignment.Center) {
                            CircularProgressIndicator(color = Gold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TextViewer(file: File, onTap: (() -> Unit)? = null) {
    val text by produceState("Loading…", file) {
        value = withContext(Dispatchers.IO) {
            runCatching { file.readText().take(200_000) }.getOrDefault("Unable to read this file.")
        }
    }
    SelectionContainer {
        Box(Modifier.fillMaxSize().background(Cream).then(if (onTap != null) Modifier.clickable { onTap() } else Modifier).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text(text, color = Navy, fontFamily = Body, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun OtherViewer(onOpen: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("This file type can't be previewed here.", color = Cream, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onOpen, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) {
            Icon(Icons.AutoMirrored.Filled.OpenInNew, null)
            Spacer(Modifier.width(8.dp))
            Text("OPEN IN ANOTHER APP", style = MaterialTheme.typography.labelLarge)
        }
    }
}
