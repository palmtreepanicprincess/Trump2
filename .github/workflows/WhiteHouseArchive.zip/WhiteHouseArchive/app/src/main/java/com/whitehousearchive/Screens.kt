package com.whitehousearchive

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.window.layout.FoldingFeature
import coil.compose.AsyncImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Posture { FLAT, BOOK, TABLETOP }

fun FoldingFeature?.posture(): Posture = when {
    this == null -> Posture.FLAT
    state == FoldingFeature.State.HALF_OPENED && orientation == FoldingFeature.Orientation.VERTICAL -> Posture.BOOK
    state == FoldingFeature.State.HALF_OPENED && orientation == FoldingFeature.Orientation.HORIZONTAL -> Posture.TABLETOP
    else -> Posture.FLAT
}

private val LETTER_MIMES = arrayOf(
    "application/pdf", "image/*", "text/*", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
)

@Composable
fun ArchiveApp(vm: ArchiveViewModel, fold: FoldingFeature?) {
    val items by vm.items.collectAsStateWithLifecycle()
    val selectedId by vm.selectedId.collectAsStateWithLifecycle()
    val selected = items.firstOrNull { it.id == selectedId }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var fullId by remember { mutableStateOf<String?>(null) }
    var pendingCat by remember { mutableStateOf(Category.CORRESPONDENCE) }

    // Folded cover screen (~350dp wide) => single pane. Unfolded inner screen (>=600dp) => two panes.
    val twoPane = LocalConfiguration.current.screenWidthDp >= 600
    val posture = fold.posture()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.import(uris, pendingCat)
    }
    BackHandler(enabled = selected != null && !twoPane) { vm.select(null) }

    val listPane: @Composable (Modifier) -> Unit = { m ->
        ListPane(items, tab, { tab = it }, selectedId, { vm.select(it) }, { vm.select(it); fullId = it }, vm::fileOf, m)
    }
    val detailPane: @Composable (Modifier) -> Unit = { m ->
        if (selected == null) {
            EmptyState(m, "Select a letter or photograph")
        } else {
            DetailPane(
                item = selected, file = vm.fileOf(selected),
                onBack = if (twoPane) null else ({ vm.select(null) }),
                onFullscreen = { fullId = selected.id },
                onSave = { t, n -> vm.update(selected, t, n) },
                onDelete = { vm.delete(selected) },
                modifier = m
            )
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { AppHeader(compact = !twoPane) },
        floatingActionButton = {
            if (twoPane || selected == null) {
                ExtendedFloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = Gold, contentColor = Navy,
                    icon = { Icon(Icons.Filled.Add, null) },
                    text = { Text("ADD", style = MaterialTheme.typography.labelLarge) }
                )
            }
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(Navy, NavyDeep)))
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when {
                !twoPane -> if (selected != null) detailPane(Modifier.fillMaxSize()) else listPane(Modifier.fillMaxSize())
                // Tabletop: hinge is horizontal -> viewer on the top half, list on the bottom half
                posture == Posture.TABLETOP -> Column(Modifier.fillMaxSize()) {
                    detailPane(Modifier.weight(1f).fillMaxWidth())
                    HorizontalDivider(color = Gold, thickness = 2.dp)
                    listPane(Modifier.weight(1f).fillMaxWidth())
                }
                // Book: hinge is vertical -> list on the left page, viewer on the right page
                posture == Posture.BOOK -> Row(Modifier.fillMaxSize()) {
                    listPane(Modifier.weight(1f).fillMaxHeight())
                    VerticalDivider(color = Gold, thickness = 2.dp)
                    detailPane(Modifier.weight(1f).fillMaxHeight())
                }
                else -> Row(Modifier.fillMaxSize()) {
                    listPane(Modifier.weight(0.38f).fillMaxHeight())
                    VerticalDivider(color = Gold.copy(alpha = .6f))
                    detailPane(Modifier.weight(0.62f).fillMaxHeight())
                }
            }
        }
    }

    val full = items.firstOrNull { it.id == fullId }
    if (full != null) {
        FullScreenViewer(full, vm.fileOf(full)) { fullId = null }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = NavyCard,
            title = { Text("Add to the Archive", color = Gold, style = MaterialTheme.typography.titleLarge) },
            text = { Text("What would you like to upload?", color = Cream) },
            confirmButton = {
                TextButton(onClick = {
                    pendingCat = Category.CORRESPONDENCE; showAdd = false; picker.launch(LETTER_MIMES)
                }) { Text("LETTERS & DOCS", color = Gold, style = MaterialTheme.typography.labelLarge) }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingCat = Category.PHOTO; showAdd = false; picker.launch(arrayOf("image/*"))
                }) { Text("PHOTOS", color = Gold, style = MaterialTheme.typography.labelLarge) }
            }
        )
    }
}

@Composable
fun AppHeader(compact: Boolean) {
    Column(Modifier.fillMaxWidth().background(Navy).statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = if (compact) 6.dp else 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SealEmblem(if (compact) 42.dp else 60.dp)
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("★  ★  ★  ★  ★", color = Gold, fontSize = 10.sp, letterSpacing = 4.sp)
                Text(
                    "PRESIDENT TRUMP",
                    color = Gold, fontWeight = FontWeight.Normal, fontFamily = Heading,
                    fontSize = if (compact) 18.sp else 28.sp,
                    letterSpacing = if (compact) 2.sp else 4.sp,
                    maxLines = 1, textAlign = TextAlign.Center
                )
                Text(
                    if (compact) "THE WHITE HOUSE" else "THE WHITE HOUSE  ·  PERSONAL ARCHIVE",
                    color = Cream, fontSize = if (compact) 10.sp else 12.sp, letterSpacing = 2.sp,
                    fontFamily = Body, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1
                )
            }
            SealEmblem(if (compact) 42.dp else 60.dp)
        }
        Box(Modifier.fillMaxWidth().height(3.dp).background(Gold))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Crimson))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Cream))
        Box(Modifier.fillMaxWidth().height(2.dp).background(Crimson))
    }
}

@Composable
fun ListPane(
    items: List<ArchiveItem>, tab: Int, onTab: (Int) -> Unit,
    selectedId: String?, onSelect: (String) -> Unit, onPhotoTap: (String) -> Unit,
    fileOf: (ArchiveItem) -> File, modifier: Modifier
) {
    val shown = when (tab) {
        1 -> items.filter { it.category == Category.CORRESPONDENCE }
        2 -> items.filter { it.category == Category.PHOTO }
        else -> items
    }
    Column(modifier) {
        TabRow(selectedTabIndex = tab, containerColor = Navy, contentColor = Gold) {
            listOf("ALL", "LETTERS", "PHOTOS").forEachIndexed { i, t ->
                Tab(
                    selected = tab == i, onClick = { onTab(i) },
                    text = {
                        Text(t, style = MaterialTheme.typography.labelLarge,
                            color = if (tab == i) Gold else Cream.copy(alpha = .7f))
                    }
                )
            }
        }
        if (shown.isEmpty()) {
            EmptyState(Modifier.fillMaxSize(), "Nothing here yet.\nTap ADD to upload your correspondence and photographs.")
        } else if (tab == 2) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp),
                contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { item ->
                    val sel = item.id == selectedId
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(6.dp))
                            .background(if (sel) Gold else NavyCard)
                            .padding(if (sel) 3.dp else 0.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .clickable { onPhotoTap(item.id) }
                    ) {
                        AsyncImage(fileOf(item), item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { item ->
                    ItemRow(item, item.id == selectedId, fileOf(item)) { onSelect(item.id) }
                }
            }
        }
    }
}

@Composable
private fun ItemRow(item: ArchiveItem, selected: Boolean, file: File, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) GoldLight else Gold.copy(alpha = .35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val thumb = Modifier.size(56.dp).clip(RoundedCornerShape(6.dp))
            if (item.kind == Kind.IMAGE) {
                AsyncImage(file, null, thumb, contentScale = ContentScale.Crop)
            } else {
                Box(thumb.background(Navy), Alignment.Center) { Icon(iconFor(item.kind), null, tint = Gold) }
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(item.title, color = Cream, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium)
                Text(
                    "${if (item.category == Category.PHOTO) "Photograph" else "Correspondence"} · ${fmt(item.addedAt)}",
                    color = Gold, style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

private fun iconFor(kind: Kind) = when (kind) {
    Kind.IMAGE -> Icons.Filled.Image
    Kind.PDF -> Icons.Filled.PictureAsPdf
    Kind.TEXT -> Icons.Filled.Description
    Kind.OTHER -> Icons.Filled.InsertDriveFile
}

private fun fmt(t: Long) = SimpleDateFormat("MMM d, yyyy", Locale.US).format(Date(t))

@Composable
fun EmptyState(modifier: Modifier, text: String) {
    Column(modifier.padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        SealEmblem(88.dp)
        Spacer(Modifier.height(12.dp))
        Text(text, color = Cream.copy(alpha = .85f), textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun DetailPane(
    item: ArchiveItem, file: File, onBack: (() -> Unit)?, onFullscreen: () -> Unit,
    onSave: (String, String) -> Unit, onDelete: () -> Unit, modifier: Modifier
) {
    val ctx = LocalContext.current
    var editing by remember(item.id) { mutableStateOf(false) }
    var confirmDelete by remember(item.id) { mutableStateOf(false) }

    Column(modifier) {
        Surface(color = Navy) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Gold) }
                    } else Spacer(Modifier.width(8.dp))
                    Text(item.title, Modifier.weight(1f), color = Gold, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleLarge)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton(onClick = onFullscreen) { Icon(Icons.Filled.Fullscreen, "Full screen", tint = Gold) }
                    IconButton(onClick = { launchExternal(ctx, file, item.mime, false) }) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, "Open in app", tint = Cream)
                    }
                    IconButton(onClick = { launchExternal(ctx, file, item.mime, true) }) {
                        Icon(Icons.Filled.Share, "Share", tint = Cream)
                    }
                    IconButton(onClick = { editing = true }) { Icon(Icons.Filled.Edit, "Edit", tint = Cream) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete", tint = Color(0xFFFF6B6B)) }
                }
                Text(
                    "Added ${fmt(item.addedAt)}" + if (item.notes.isNotBlank()) "  ·  ${item.notes}" else "",
                    Modifier.padding(start = 12.dp, bottom = 4.dp), color = Cream.copy(alpha = .8f),
                    style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(Modifier.height(2.dp).fillMaxWidth().background(Gold))
        // Tap the photo / document to open it full screen
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF0B0B0F))) {
            when (item.kind) {
                Kind.IMAGE -> ImageViewer(file, onFullscreen)
                Kind.PDF -> PdfViewer(file, onFullscreen)
                Kind.TEXT -> TextViewer(file, onFullscreen)
                Kind.OTHER -> OtherViewer { launchExternal(ctx, file, item.mime, false) }
            }
        }
    }

    if (editing) {
        var title by remember { mutableStateOf(item.title) }
        var notes by remember { mutableStateOf(item.notes) }
        AlertDialog(
            onDismissRequest = { editing = false },
            containerColor = NavyCard,
            title = { Text("Edit details", color = Gold, style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(notes, { notes = it }, label = { Text("Notes (date, sender, occasion…)") }, minLines = 3)
                }
            },
            confirmButton = { TextButton(onClick = { onSave(title, notes); editing = false }) { Text("SAVE", color = Gold) } },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("CANCEL", color = Cream) } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = NavyCard,
            title = { Text("Delete this item?", color = Gold) },
            text = { Text("It will be removed from this app. Your original file is not affected.", color = Cream) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("DELETE", color = GoldLight) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("CANCEL", color = Cream) } }
        )
    }
}

/** Edge-to-edge viewer. Photos: pinch / double-tap to zoom. Documents: scroll. X (or Back) closes. */
@Composable
fun FullScreenViewer(item: ArchiveItem, file: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            when (item.kind) {
                Kind.IMAGE -> ImageViewer(file)
                Kind.PDF -> Box(Modifier.fillMaxSize().padding(top = 64.dp)) { PdfViewer(file) }
                Kind.TEXT -> Box(Modifier.fillMaxSize().padding(top = 64.dp)) { TextViewer(file) }
                Kind.OTHER -> OtherViewer { launchExternal(ctx, file, item.mime, false) }
            }
            Row(
                Modifier.fillMaxWidth().background(Color(0xCC0A1F44)).statusBarsPadding().padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close", tint = Gold) }
                Text(item.title, Modifier.weight(1f), color = Gold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                Text("★", color = Gold, modifier = Modifier.padding(end = 16.dp))
            }
        }
    }
}

private fun launchExternal(ctx: Context, file: File, mime: String, share: Boolean) {
    runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val intent = if (share) Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri) }
        else Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime) }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(if (share) Intent.createChooser(intent, null) else intent)
    }.onFailure { Toast.makeText(ctx, "No app available to open this file.", Toast.LENGTH_SHORT).show() }
}
