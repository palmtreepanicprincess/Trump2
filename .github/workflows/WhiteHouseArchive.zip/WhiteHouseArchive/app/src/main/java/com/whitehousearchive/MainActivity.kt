package com.whitehousearchive

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.webkit.WebView
import android.webkit.WebSettings
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Serif)) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0A1A3A)) {
                        PresidentialBinderApp()
                    }
                }
            }
        }
    }
}

private val Navy = Color(0xFF0A1A3A)
private val NavyLight = Color(0xFF132A5C)
private val Gold = Color(0xFFD4AF37)
private val Paper = Color(0xFFF4ECD8)
private val Ink = Color(0xFF1A1410)

data class Item(val uri: String, var title: String, var type: String, var note: String = "", var favorite: Boolean = false)

@Composable
fun PresidentialBinderApp() {
    var opened by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.85f) }
    val rotation = remember { Animatable(-12f) }
    LaunchedEffect(Unit) {
        delay(200)
        scale.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        rotation.animateTo(0f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        delay(400)
        opened = true
    }
    Box(
        modifier = Modifier.fillMaxSize().systemBarsPadding()
            .background(Brush.radialGradient(listOf(NavyLight, Navy, Color(0xFF050E22)))),
        contentAlignment = Alignment.Center
    ) {
        if (!opened) {
            Box(
                modifier = Modifier.scale(scale.value).graphicsLayer { rotationY = rotation.value }
                    .size(width = 260.dp, height = 340.dp).clip(RoundedCornerShape(8.dp))
                    .background(Brush.verticalGradient(listOf(NavyLight, Navy)))
                    .border(2.dp, Gold, RoundedCornerShape(8.dp)).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("THE WHITE HOUSE", color = Gold, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("PRESIDENT", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Text("TRUMP", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { repeat(4) { Box(Modifier.size(14.dp).clip(RoundedCornerShape(7.dp)).background(Gold)) } }
                    Spacer(Modifier.height(24.dp))
                    Text("CORRESPONDENCE & PHOTOS", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
                }
            }
        } else {
            ArchiveInterior()
        }
    }
}

@Composable
fun Seal() {
    Box(Modifier.size(52.dp).clip(CircleShape).background(Gold).border(2.dp, Color(0xFFB8962E), CircleShape), contentAlignment = Alignment.Center) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) {
            Text("★", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ArchiveInterior() {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("archive", Context.MODE_PRIVATE)
    fun load(): MutableList<Item> {
        val json = prefs.getString("items", "[]") ?: "[]"
        val arr = JSONArray(json)
        val list = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Item(o.getString("uri"), o.getString("title"), o.getString("type"), o.optString("note", ""), o.optBoolean("favorite", false)))
        }
        return list
    }
    fun save(list: List<Item>) {
        val arr = JSONArray()
        list.forEach { it -> val o = JSONObject(); o.put("uri", it.uri); o.put("title", it.title); o.put("type", it.type); o.put("note", it.note); o.put("favorite", it.favorite); arr.put(o) }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    var items by remember { mutableStateOf(load()) }
    var selected by remember { mutableStateOf<Item?>(null) }
    var fullScreen by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("ALL", "LETTERS", "PHOTOS", "TRUTH", "NOTES")
    var editItem by remember { mutableStateOf<Item?>(null) }
    var editText by remember { mutableStateOf("") }
    var editNote by remember { mutableStateOf("") }
    var editType by remember { mutableStateOf("") }
    var showConfirm by remember { mutableStateOf(false) }
    var dedication by remember { mutableStateOf(prefs.getString("dedication", "To the memories of the Trump White House.") ?: "") }
    var showDedication by remember { mutableStateOf(true) }
    LaunchedEffect(showDedication) {
        if (!showDedication) {
            val v = context.getSystemService(android.os.Vibrator::class.java)
            v?.vibrate(android.os.VibrationEffect.createOneShot(200, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            val mp = android.media.MediaPlayer.create(context, com.whitehousearchive.R.raw.hold_on)
            mp?.start()
        }
    }
    var editingDedication by remember { mutableStateOf(false) }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        val newItems = uris.map { uri ->
            val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
            val isImg = mime?.startsWith("image/") == true || (uri.lastPathSegment ?: "").lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") }
            Item(uri.toString(), uri.lastPathSegment ?: "Item", if (isImg) "Photo" else "Letter")
        }
        items = (items + newItems).toMutableList()
        save(items)
    }

    BackHandler(enabled = fullScreen != null || selected != null) {
        if (fullScreen != null) fullScreen = null
        else selected = null
    }
    if (showDedication) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("DEDICATION", color = Gold, fontSize = 14.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            if (editingDedication) {
                TextField(value = dedication, onValueChange = { dedication = it }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Button(onClick = { prefs.edit().putString("dedication", dedication).apply(); editingDedication = false }) { Text("Save") }
            } else {
                Text(dedication, color = Color.White, fontSize = 18.sp, fontFamily = FontFamily.Serif, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { editingDedication = true }) { Text("Edit") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { showDedication = false }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) { Text("Enter Archive") }
            }
        }
        return
    }
    if (fullScreen != null) {
        Box(Modifier.fillMaxSize().background(Navy).clickable { fullScreen = null }, contentAlignment = Alignment.Center) {
            AsyncImage(model = Uri.parse(fullScreen), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
        return
    }

    val filtered = (when (tab) {
        1 -> items.filter { it.type == "Letter" }
        2 -> items.filter { it.type == "Photo" }
        else -> items
    }).sortedByDescending { it.favorite }

    // Notes
    data class Note(val id: Long, var text: String)
    fun loadNotes(): MutableList<Note> {
        val arr = org.json.JSONArray(prefs.getString("notes", "[]"))
        val l = mutableListOf<Note>()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); l.add(Note(o.getLong("id"), o.getString("text"))) }
        return l
    }
    fun saveNotes(l: List<Note>) {
        val arr = org.json.JSONArray()
        l.forEach { val o = org.json.JSONObject(); o.put("id", it.id); o.put("text", it.text); arr.put(o) }
        prefs.edit().putString("notes", arr.toString()).apply()
    }
    var notes by remember { mutableStateOf(loadNotes()) }
    var newNote by remember { mutableStateOf("") }
    var showNoteDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(NavyLight).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Seal()
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PRESIDENT TRUMP", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                Text("THE WHITE HOUSE", color = Gold, fontSize = 14.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                Text("MAY'S PERSONAL ARCHIVE", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
            Seal()
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().background(NavyLight).padding(4.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.Center) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, color = if (tab == i) Gold else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxSize().padding(8.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight().padding(end = 4.dp)) {
                when (tab) {
                    3 -> {
                        Text("TRUTH SOCIAL", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("TRUTH SOCIAL", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                            Spacer(Modifier.height(8.dp))
                            Text("This opens Donald Trump's official Truth Social profile in your browser, where you can read his latest posts in date order.", color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = {
                                val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://truthsocial.com/@realDonaldTrump"))
                                context.startActivity(i)
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) { Text("Open Trump's Truth Social") }
                        }
                    }
                    4 -> {
                        Button(onClick = { showNoteDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) { Text("ADD NOTE", fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(notes) { note ->
                                Card(colors = CardDefaults.cardColors(containerColor = NavyLight), shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text(note.text, color = Color.White, fontSize = 13.sp)
                                        Spacer(Modifier.height(4.dp))
                                        var confirmDel by remember { mutableStateOf(false) }
                                        androidx.compose.material3.TextButton(onClick = { confirmDel = true }) { Text("delete", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp) }
                                        if (confirmDel) {
                                            AlertDialog(onDismissRequest = { confirmDel = false }, title = { Text("Delete note?", color = Color.White) }, text = { Text("This cannot be undone.", color = Color.White) }, confirmButton = { Button(onClick = { notes = notes.filter { it != note }.toMutableList(); saveNotes(notes); confirmDel = false }) { Text("Delete") } }, dismissButton = { Button(onClick = { confirmDel = false }) { Text("Cancel") } }, containerColor = NavyLight)
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val f = java.io.File(context.filesDir, "backup.json")
                                f.writeText(org.json.JSONObject().apply { put("items", org.json.JSONArray().apply { items.forEach { o -> put(org.json.JSONObject().apply { put("uri", o.uri); put("title", o.title); put("type", o.type); put("note", o.note); put("favorite", o.favorite) }) } }); put("notes", org.json.JSONArray().apply { notes.forEach { o -> put(org.json.JSONObject().apply { put("id", o.id); put("text", o.text) }) } }); put("dedication", dedication) }.toString())
                            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) { Text("Backup") }
                            Button(onClick = {
                                val f = java.io.File(context.filesDir, "backup.json")
                                if (f.exists()) {
                                    val o = org.json.JSONObject(f.readText())
                                    val arr = o.getJSONArray("items")
                                    val list = mutableListOf<Item>()
                                    for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); list.add(Item(x.getString("uri"), x.getString("title"), x.getString("type"), x.optString("note", ""), x.optBoolean("favorite", false))) }
                                    items = list
                                    save(items)
                                    val nArr = o.getJSONArray("notes")
                                    val nList = mutableListOf<Note>()
                                    for (i in 0 until nArr.length()) { val x = nArr.getJSONObject(i); nList.add(Note(x.getLong("id"), x.getString("text"))) }
                                    notes = nList
                                    saveNotes(notes)
                                    dedication = o.optString("dedication", dedication)
                                    prefs.edit().putString("dedication", dedication).apply()
                                }
                            }, colors = ButtonDefaults.buttonColors(containerColor = NavyLight, contentColor = Gold)) { Text("Restore") }
                        }
                    }
                    else -> {
                        Button(onClick = { picker.launch(arrayOf("image/*", "application/pdf", "*/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) { Text("ADD", fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(8.dp))
                        Column(Modifier.fillMaxWidth().clickable { selected = null }) {
                            androidx.compose.foundation.layout.FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                filtered.forEach { item ->
                                    val uri = Uri.parse(item.uri)
                                    val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
                                    val isImg = (mime?.startsWith("image/") == true) || item.type == "Photo"
                                    if (isImg) {
                                        AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(84.dp).aspectRatio(1f).clip(RoundedCornerShape(4.dp)).border(if (selected == item) 3.dp else 1.dp, if (selected == item) Color.White else Gold, RoundedCornerShape(4.dp)).pointerInput(item) { detectTapGestures(onTap = { selected = item }, onLongPress = { editItem = item; editText = item.title }) })
                                    } else {
                                        Card(colors = CardDefaults.cardColors(containerColor = Paper), shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selected = item }.pointerInput(item) { detectTapGestures(onLongPress = { editItem = item; editText = item.title; editNote = item.note; editType = item.type }) }) {
                                            Text(item.title, color = Ink, modifier = Modifier.padding(10.dp), fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 4.dp)) {
                if (selected != null) {
                    val item = selected!!
                    val uri = Uri.parse(item.uri)
                    val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
                    val isImg = (mime?.startsWith("image/") == true) || item.type == "Photo"
                    Card(colors = CardDefaults.cardColors(containerColor = NavyLight), shape = RoundedCornerShape(4.dp), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp), modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                            Text(item.type.uppercase(), color = Gold, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                            if (item.note.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(item.note, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, fontFamily = FontFamily.Serif) }
                            Spacer(Modifier.height(12.dp))
                            if (isImg) {
                                AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(400.dp).clickable { fullScreen = item.uri })
                            }
                            Spacer(Modifier.height(12.dp))
                            androidx.compose.material3.TextButton(onClick = { showConfirm = true }) { Text("delete", color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp) }
                            if (showConfirm) {
                                AlertDialog(
                                    onDismissRequest = { showConfirm = false },
                                    title = { Text("Delete?", color = Color.White) },
                                    text = { Text("Remove this item from the app? The original file is not deleted.", color = Color.White) },
                                    confirmButton = { Button(onClick = { items = items.filter { it != item }.toMutableList(); save(items); selected = null; showConfirm = false }) { Text("Delete") } },
                                    dismissButton = { Button(onClick = { showConfirm = false }) { Text("Cancel") } },
                                    containerColor = NavyLight
                                )
                            }
                        }
                    }
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Select an item to view", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                    }
                }
            }
        }
    }

    if (showNoteDialog) {
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            title = { Text("New Note", color = Color.White) },
            text = { TextField(value = newNote, onValueChange = { newNote = it }, modifier = Modifier.height(200.dp)) },
            confirmButton = { Button(onClick = { notes = (notes + Note(System.currentTimeMillis(), newNote)).toMutableList(); saveNotes(notes); newNote = ""; showNoteDialog = false }) { Text("Save") } },
            dismissButton = { Button(onClick = { showNoteDialog = false }) { Text("Cancel") } },
            containerColor = NavyLight
        )
    }
    if (editItem != null) {
        AlertDialog(
            onDismissRequest = { editItem = null },
            title = { Text("Rename", color = Color.White) },
            text = { Column { TextField(value = editText, onValueChange = { editText = it }, label = { Text("Title") }); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { editType = "Letter" }, colors = ButtonDefaults.buttonColors(containerColor = if (editType == "Letter") Gold else NavyLight)) { Text("Letter") }; Button(onClick = { editType = "Photo" }, colors = ButtonDefaults.buttonColors(containerColor = if (editType == "Photo") Gold else NavyLight)) { Text("Photo") } }; Spacer(Modifier.height(8.dp)); TextField(value = editNote, onValueChange = { editNote = it }, label = { Text("Story note") }); Spacer(Modifier.height(8.dp)); Button(onClick = { editItem!!.favorite = !editItem!!.favorite }, colors = ButtonDefaults.buttonColors(containerColor = if (editItem!!.favorite) Gold else NavyLight)) { Text(if (editItem!!.favorite) "Favourited" else "Favourite") } } },
            confirmButton = { Button(onClick = { editItem!!.title = editText; editItem!!.note = editNote; editItem!!.type = editType; items = items.toMutableList(); save(items); editItem = null }) { Text("Save") } },
            dismissButton = { Button(onClick = { editItem = null }) { Text("Cancel") } },
            containerColor = NavyLight
        )
    }
}
}
