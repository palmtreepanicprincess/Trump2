package com.whitehousearchive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF1A1410)) {
                    PresidentialBinderApp()
                }
            }
        }
    }
}

private val LeatherDark = Color(0xFF2B1D12)
private val LeatherLight = Color(0xFF4A3220)
private val Gold = Color(0xFFD4AF37)
private val Paper = Color(0xFFF4ECD8)
private val PaperDark = Color(0xFFE8DDC0)
private val Ink = Color(0xFF1A1410)

@Composable
fun PresidentialBinderApp() {
    var opened by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.85f) }
    val rotation = remember { Animatable(-12f) }

    LaunchedEffect(Unit) {
        delay(200)
        scale.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        rotation.animateTo(0f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        delay(400)
        opened = true
    }

    Box(
        modifier = Modifier.fillMaxSize().systemBarsPadding()
            .background(Brush.radialGradient(listOf(LeatherLight, LeatherDark, Color(0xFF0E0906)))),
        contentAlignment = Alignment.Center
    ) {
        if (!opened) {
            Box(
                modifier = Modifier.scale(scale.value).graphicsLayer { rotationY = rotation.value }
                    .size(width = 260.dp, height = 340.dp).clip(RoundedCornerShape(8.dp))
                    .background(Brush.verticalGradient(listOf(LeatherLight, LeatherDark)))
                    .border(2.dp, Gold, RoundedCornerShape(8.dp)).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("THE WHITE HOUSE", color = Gold, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("PRESIDENTIAL", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Text("ARCHIVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        repeat(4) { Box(Modifier.size(14.dp).clip(RoundedCornerShape(7.dp)).background(Gold)) }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("CLASSIFIED", color = Gold, fontSize = 11.sp, letterSpacing = 4.sp)
                }
            }
        } else {
            BinderInterior()
        }
    }
}

@Composable
fun BinderInterior() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Photos", "Correspondence")
    val photos = remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    val docs = remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }

    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> photos.value = uris }
    val docPicker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> docs.value = uris }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(6.dp).height(48.dp).background(Gold))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("PRESIDENTIAL BINDER", color = Gold, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Text("Your White House Archive", color = Color.White, fontSize = 22.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            repeat(6) { Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Gold)) }
        }
        Spacer(Modifier.height(12.dp))
        TabRow(selectedTabIndex = selectedTab, containerColor = LeatherDark, contentColor = Gold) {
            tabs.forEachIndexed { i, t -> Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(t, color = if (selectedTab == i) Gold else Color.White) }) }
        }
        Spacer(Modifier.height(12.dp))
        when (selectedTab) {
            0 -> {
                Button(onClick = { photoPicker.launch("image/*") }) { Text("Pick Photos") }
                Spacer(Modifier.height(8.dp))
                LazyVerticalGrid(columns = GridCells.Adaptive(100.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(photos.value) { uri ->
                        AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(4.dp)).border(1.dp, Gold, RoundedCornerShape(4.dp)))
                    }
                }
            }
            else -> {
                Button(onClick = { docPicker.launch(arrayOf("*/*")) }) { Text("Pick Documents") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(docs.value) { uri ->
                        Card(colors = CardDefaults.cardColors(containerColor = Paper), shape = RoundedCornerShape(4.dp)) {
                            Text(uri.lastPathSegment ?: uri.toString(), color = Ink, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }
    }
}
