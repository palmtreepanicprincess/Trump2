package com.whitehousearchive

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                androidx.compose.runtime.CompositionLocalProvider(LocalTextStyle provides TextStyle(fontFamily = FontFamily.Serif)) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0A1A3A)) {
                    PresidentialBinderApp()
                }
                }
            }
        }
    }
}

private val Navy = Color(0xFF0A1A3A)
private val NavyLight = Color(0xFF132A5C)
private val Gold = Color(0xFFD4AF37)
private val Paper = Color(0xFFF4ECD8)
private val Ink = Color(0xFF1A1410)

@Composable
fun PresidentialBinderApp() {
    var opened by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.85f) }
    val rotation = remember { Animatable(-12f) }
    LaunchedEffect(Unit) {
        delay(200)
        scale.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        rotation.animateTo(0f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        delay(400)
        opened = true
    }
    Box(
        modifier = Modifier.fillMaxSize().systemBarsPadding()
            .background(Brush.radialGradient(listOf(NavyLight, Navy, Color(0xFF050E22)))),
        contentAlignment = Alignment.Center
    ) {
        if (!opened) {
            Box(
                modifier = Modifier.scale(scale.value).graphicsLayer { rotationY = rotation.value }
                    .size(width = 260.dp, height = 340.dp).clip(RoundedCornerShape(8.dp))
                    .background(Brush.verticalGradient(listOf(NavyLight, Navy)))
                    .border(2.dp, Gold, RoundedCornerShape(8.dp)).padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("THE WHITE HOUSE", color = Gold, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("PRESIDENT", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Text("TRUMP", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { repeat(4) { Box(Modifier.size(14.dp).clip(RoundedCornerShape(7.dp)).background(Gold)) } }
                    Spacer(Modifier.height(24.dp))
                    Text("CORRESPONDENCE & PHOTOS", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
                }
            }
        } else {
            ArchiveInterior()
        }
    }
}

@Composable
fun Seal() {
    Box(Modifier.size(52.dp).clip(CircleShape).background(Gold).border(2.dp, Color(0xFFB8962E), CircleShape), contentAlignment = Alignment.Center) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) {
            Text("★", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ArchiveInterior() {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("archive", Context.MODE_PRIVATE)
    fun load(): MutableList<String> = prefs.getStringSet("items", emptySet())?.toMutableList() ?: mutableListOf()
    fun save(list: List<String>) { prefs.edit().putStringSet("items", list.toSet()).apply() }

    var items by remember { mutableStateOf(load().map { Uri.parse(it) }.toMutableList()) }
    var selected by remember { mutableStateOf<Uri?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    var fullScreen by remember { mutableStateOf<Uri?>(null) }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        items = (items + uris).distinct().toMutableList()
        save(items.map { it.toString() })
    }

    if (fullScreen != null) {
        Box(Modifier.fillMaxSize().background(Navy).clickable { fullScreen = null }, contentAlignment = Alignment.Center) {
            AsyncImage(model = fullScreen, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().background(NavyLight).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Seal()
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PRESIDENT TRUMP", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                Text("THE WHITE HOUSE", color = Gold, fontSize = 14.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                Text("Correspondence & Photos", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
            Seal()
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxSize().padding(8.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight().padding(end = 4.dp)) {
                Button(onClick = { picker.launch(arrayOf("image/*", "application/pdf", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Add Items") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items) { uri ->
                        val name = uri.lastPathSegment ?: uri.toString()
                        val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
                        val isImg = (mime?.startsWith("image/") == true) || name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Paper),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selected = uri }
                        ) {
                            if (isImg) {
                                AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(64.dp).aspectRatio(1f))
                            } else {
                                Text(name, color = Ink, modifier = Modifier.padding(10.dp), fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 4.dp)) {
                if (selected != null) {
                    val name = selected!!.lastPathSegment ?: ""
                    val mime = try { context.contentResolver.getType(selected!!) } catch (_: Exception) { null }
                    val isImg = (mime?.startsWith("image/") == true) || name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") }
                    Card(colors = CardDefaults.cardColors(containerColor = NavyLight), shape = RoundedCornerShape(4.dp), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp), modifier = Modifier.fillMaxSize()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("ITEM", color = Ink, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(selected!!.lastPathSegment ?: "", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                            Spacer(Modifier.height(12.dp))
                            if (isImg) {
                                AsyncImage(model = selected, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(400.dp).clickable { fullScreen = selected })
                            }
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { showConfirm = true }) { Text("Delete from App") }
                            if (showConfirm) {
                                AlertDialog(
                                    onDismissRequest = { showConfirm = false },
                                    title = { Text("Delete?", color = Color.White) },
                                    text = { Text("Remove this item from the app? The original file is not deleted.", color = Color.White) },
                                    confirmButton = { Button(onClick = { items = items.filter { it != selected }.toMutableList(); save(items.map { it.toString() }); selected = null; showConfirm = false }) { Text("Delete") } },
                                    dismissButton = { Button(onClick = { showConfirm = false }) { Text("Cancel") } },
                                    containerColor = NavyLight
                                )
                            }
                        }
                    }
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Select an item to view", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
