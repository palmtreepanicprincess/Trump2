package com.whitehousearchive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF1A1410)) {
                    PresidentialBinderApp()
                }
            }
        }
    }
}

private val LeatherDark = Color(0xFF2B1D12)
private val LeatherLight = Color(0xFF4A3220)
private val Gold = Color(0xFFD4AF37)
private val Paper = Color(0xFFF4ECD8)
private val PaperDark = Color(0xFFE8DDC0)
private val Ink = Color(0xFF1A1410)

data class Document(val title: String, val date: String, val classification: String)

@Composable
fun PresidentialBinderApp() {
    var opened by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.85f) }
    val rotation = remember { Animatable(-12f) }

    LaunchedEffect(Unit) {
        delay(200)
        scale.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        rotation.animateTo(0f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        delay(400)
        opened = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(listOf(LeatherLight, LeatherDark, Color(0xFF0E0906)))
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!opened) {
            // Closed binder cover
            Box(
                modifier = Modifier
                    .scale(scale.value)
                    .graphicsLayer { rotationY = rotation.value }
                    .size(width = 260.dp, height = 340.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Brush.verticalGradient(listOf(LeatherLight, LeatherDark)))
                    .border(2.dp, Gold, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("THE WHITE HOUSE", color = Gold, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("PRESIDENTIAL", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Text("ARCHIVE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(Modifier.height(16.dp))
                    // binder rings
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        repeat(4) {
                            Box(Modifier.size(14.dp).clip(RoundedCornerShape(7.dp)).background(Gold))
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("CLASSIFIED", color = Gold, fontSize = 11.sp, letterSpacing = 4.sp)
                }
            }
        } else {
            BinderInterior()
        }
    }
}

@Composable
fun BinderInterior() {
    val docs = remember {
        listOf(
            Document("Executive Order 14110 — AI Safety", "Oct 30, 2023", "CONFIDENTIAL"),
            Document("National Security Memo 22", "Mar 15, 2024", "SECRET"),
            Document("Budget Reconciliation Draft", "Jun 02, 2024", "RESTRICTED"),
            Document("Diplomatic Cable — NATO Summit", "Jul 11, 2024", "SECRET"),
            Document("Presidential Daily Brief (PDB)", "Aug 05, 2024", "TOP SECRET"),
            Document("Clemency Review — Batch 14", "Sep 18, 2024", "CONFIDENTIAL"),
            Document("Disaster Declaration — Hurricane Helene", "Sep 28, 2024", "PUBLIC"),
            Document("Transition Planning Memo", "Nov 07, 2024", "RESTRICTED")
        )
    }
    var selected by remember { mutableStateOf<Document?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Binder header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(6.dp).height(48.dp).background(Gold))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("PRESIDENTIAL BINDER", color = Gold, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Text("Documents of Record", color = Color.White, fontSize = 22.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        // rings
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            repeat(6) { Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Gold)) }
        }
        Spacer(Modifier.height(16.dp))

        if (selected == null) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(docs) { doc ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = doc },
                        colors = CardDefaults.cardColors(containerColor = Paper),
                        shape = RoundedCornerShape(4.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(doc.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = FontFamily.Serif)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(doc.date, color = Ink.copy(alpha = 0.6f), fontSize = 12.sp)
                                Text(doc.classification, color = classificationColor(doc.classification), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                    }
                }
            }
        } else {
            DocumentView(selected!!) { selected = null }
        }
    }
}

@Composable
fun DocumentView(doc: Document, onBack: () -> Unit) {
    Column {
        Text("< Back to binder", color = Gold, modifier = Modifier.clickable { onBack() }.padding(4.dp), fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Paper),
            shape = RoundedCornerShape(2.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp)) {
                Text("UNITED STATES OF AMERICA", color = Ink, fontSize = 11.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(2.dp))
                Text("EXECUTIVE OFFICE OF THE PRESIDENT", color = Ink, fontSize = 11.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Text(doc.title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Text("Date: ${doc.date}", color = Ink, fontSize = 13.sp)
                Text("Classification: ${doc.classification}", color = classificationColor(doc.classification), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(24.dp))
                Text(
                    "This document is part of the Presidential Archive. Contents are maintained for the historical record of the Office of the President. Handle in accordance with classification guidelines.",
                    color = Ink.copy(alpha = 0.8f), fontSize = 13.sp, lineHeight = 20.sp
                )
                Spacer(Modifier.height(32.dp))
                Text("— END OF DOCUMENT —", color = Ink.copy(alpha = 0.5f), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

private fun classificationColor(c: String): Color = when (c) {
    "TOP SECRET" -> Color(0xFF8B0000)
    "SECRET" -> Color(0xFFB22222)
    "CONFIDENTIAL" -> Color(0xFF8B6914)
    "RESTRICTED" -> Color(0xFF556B2F)
    else -> Color(0xFF2F4F4F)
}
